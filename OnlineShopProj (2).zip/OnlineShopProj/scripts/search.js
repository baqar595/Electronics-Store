

const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');


searchBtn.addEventListener('click', () => {
  const query = searchInput.value.toLowerCase().trim();
  const filtered = products.filter(p => p.name.toLowerCase().includes(query));
  renderSearchResults(filtered);
});


function renderSearchResults(productList) {
  const container = document.getElementById('searchResults');

  if (productList.length === 0) {
    container.innerHTML = '<p>No products found.</p>';
    return;
  }

  container.innerHTML = productList.map(p => `
    <div class="product-card mb-3 p-3 border rounded shadow-sm">
      <h5>${p.name}</h5>
      <img src="${p.image}" alt="${p.name}" style="max-width:150px; height:auto;">
      <p><strong>Rs.${p.discountedPrice}</strong></p>
      <button onclick="AddToCartById(${p.id})" class="btn btn-success btn-sm me-2">Add to Cart</button>
      <button class="favorite-btn btn btn-outline-danger btn-sm" data-id="${p.id}">Favorite</button>
    </div>
  `).join('');
}

function AddToCartById(id) {
  const p = products.find(prod => prod.id == id);
  if (!p) return;

  const existing = cart.find(item => item.id == id);
  if (existing) {
    existing.quantity++;
  } else {
    cart.push({
      id: p.id,
      name: p.name,
      price: p.discountedPrice,
      image: p.image || '',
      quantity: 1
    });
  }
  Storage.save("cart", cart);
  updateCartUI();

}
function AddToFavoritesById(id) {
  const p = products.find(prod => prod.id == id);
  if (!p) return;

  if (!favorites.includes(id)) {
    favorites.push(id);
    localStorage.setItem("favorites", JSON.stringify(favorites));
  }
Storage.save("favorites", favorites);
updateFavoritesUI(); 

}

function OpenSearch() {

}



