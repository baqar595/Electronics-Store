let products = [], cart = [], favorites = [];

// Utility: Load/Save from localStorage
const Storage = {
  save(key, value) { localStorage.setItem(key, JSON.stringify(value)); },
  load(key, fallback) { return JSON.parse(localStorage.getItem(key)) || fallback; }
};

// Initialize state from localStorage
cart = Storage.load("cart", []);
favorites = Storage.load("favorites", []);

// Event Delegation
document.addEventListener('click', e => {
  const favBtn = e.target.closest('.favorite-btn');
  const removeFavBtn = e.target.closest('.remove-favorite-btn');
  const removeCartBtn = e.target.closest('.remove-cart-btn');

  if (favBtn) handleFavorite(favBtn.dataset.id);
  if (removeFavBtn) removeFavorite(removeFavBtn.dataset.index);
  if (removeCartBtn) removeFromCart(removeCartBtn.dataset.index);
});

function handleFavorite(id) {
  if (!favorites.includes(id)) favorites.push(id);
  Storage.save("favorites", favorites);
 
}






// Cart Functions

function OpenCart() {
document.querySelector('.shopping-cart').classList.toggle('open');


}
window.AddToCart = id => {
  const existing = cart.find(item => item.id == id);
  if (existing) existing.quantity++;
  else {
    const p = products[id];
    cart.push({ id, name: p.name, price: p.discountedPrice , image: p.image  || 9800, quantity: 1 });
  }
  Storage.save("cart", cart);
  updateCartUI();
  document.querySelector('.shopping-cart').classList.add('open');
};


function removeFromCart(index) {
  cart.splice(index, 1);
  Storage.save("cart", cart);
  updateCartUI();
}

function updateCartUI() {
  const el = document.querySelector('.cart-items');
  el.innerHTML = cart.map((item, i) => `
    <div class="cart-item">
      <div class="item-info">
        <img src="${item.image}" alt="${item.name}" class="item-image">
        <div class="item-details">
          <strong>${item.name}</strong><br>
          x${item.quantity} - Rs.${(item.price * item.quantity).toLocaleString()}
        </div>
      </div>
      <button class="remove-cart-btn" data-index="${i}">Remove</button>
    </div>`).join('');

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  document.querySelector('.cart-total').textContent = `Total: Rs.${total.toLocaleString()}`;
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelector('.TheExitButton').addEventListener('click', () =>
    document.querySelector('.shopping-cart').classList.remove('open')
  );
  updateCartUI();  // restore cart after refresh
});


//favorites

document.getElementById('openFavoritesBtn').addEventListener('click', renderFavorites);
function renderFavorites() {
  const list = document.getElementById('favoritesList');
  list.innerHTML = favorites.length 
    ? favorites.map((id, i) => {
     const p = products.find(prod => prod.id == id);
     if(!p) return '';
      return `<div class="favorite-item mb-2 p-2 border rounded">
        <strong>${p.name}</strong><br>
        <img src="${p.image}" style="width:100px;height:auto;"><br>
        <button class="btn btn-sm btn-danger remove-favorite-btn" data-index="${i}">Remove</button>
      </div>`;
    }).join('')
    : '<p>No favorites yet!</p>';
    

  document.getElementById('favoritesModal').style.display = 'block';
}
function closeFavorites() { document.getElementById('favoritesModal').style.display = 'none'; }

function ToggleFavorites() {
  const modal = document.getElementById('favoritesModal');
  if (modal.style.display === 'block') {
    modal.style.display = 'none';
  } else {
     renderFavorites()
    modal.style.display = 'block'; 
    
  }
}

   



function removeFavorite(index) {
  favorites.splice(index, 1);
  Storage.save("favorites", favorites);
  renderFavorites();
}



