// Unify Data Loading

Promise.all([
  fetch('Database/db.json').then(r => r.json()),
  fetch('Database/db2.json').then(r => r.json())
]).then(([db, db2]) => {
  products = db2;

  // Featured Carousel
  document.querySelector(".carousel-inner").innerHTML = db.featured.slice(0, 3).map((el, i) => `
    <div class="carousel-item ${i === 0 ? 'active' : ''}">
      <img class="d-block w-100" src="${el.image}">
      <div class="carousel-caption d-none d-md-block">
        <h5>${el.title}</h5><p>${el.subtitle}</p><p>${el.description}</p>
        ${el.button ? `<a class="btn btn-light" href="#">${el.button}</a>` : ''}
      </div></div>`).join('');

  // Promo Cards
  [db.featured[3], db.featured[4]].forEach((item, i) => {
    document.querySelector([ '.Product-item1', '.Product-item2' ][i]).innerHTML = `
      <div class="promo-card d-flex align-items-center text-white p-4 rounded mb-3"
           style="background: linear-gradient(to right, #7a003d, #1e004e); height: 180px;">
        <div class="flex-grow-1">
          <h5>${item.title}</h5><h6>${item.subtitle}</h6><p class="text-white-50">${item.description}</p>
        </div><div class="ms-4"><img src="${item.image}" style="height:140px;" class="img-fluid"></div></div>`;
  });

  // Categories
  document.querySelector(".category-carousel").innerHTML = db.categories.map(c => `
    <div class="item text-center">
      <img src="${c.image}" class="img-fluid mb-2" style="height: 100px;">
      <p>${c.name}</p><small>${c.items}</small></div>`).join('');
  $('.category-carousel').owlCarousel({ loop:true, margin:70, nav:true, dots:false, responsive:{0:{items:2},600:{items:3},1920:{items:10} , 1000:{items:4}, 1300:{items:7}} });

  // Unified Product Rendering
  const renderProductList = (selector, width = "280px", height = "200px") => {
  document.querySelector(selector).innerHTML = db2.map((p, i) => `
    <div class="product-card">
      <span class="badge">-${p.discount}%</span>
      <div class="position-relative">
        <img src="${p.image}" alt="${p.name}" style="height:${height}; width:100%; object-fit:cover;">
        <div class="action-buttons">
          <button class="favorite-btn" data-id="${p.id}">
            <i class="bi bi-heart"></i>
          </button>
        </div>
      </div>
      
      <h6>${p.name}</h6>
      <p class="text-muted small">${p.description}</p>
      
      <div class="text-warning mb-2">
        ${'★'.repeat(p.rating)}${'☆'.repeat(5-p.rating)} 
        <small>(${p.reviews} review${p.reviews !== 1 ? 's' : ''})</small>
      </div>
      
      <div class="price-section">
        <span class="text-decoration-line-through text-muted">
          Rs.${p.originalPrice.toLocaleString()}
        </span>
        <br>
        <strong>Rs.${p.discountedPrice.toLocaleString()}</strong>
      </div>
      
      <button class="btn-add-cart" onclick="AddToCart(${p.id})">
        Add to cart
      </button>
    </div>
  `).join('');
};
  


renderProductList('.FreatureProd-carousel');
  renderProductList('.PopularProd-carousel');
  renderProductList('.RecomendedProd-carousel');


  $('.FreatureProd-carousel').owlCarousel({
  loop: false,
  margin: 20,
  nav: true,
  dots: false,
  responsive: {
    0: { items: 1 },
    600: { items: 2 },
    1000: { items: 3 },
    1200: { items: 4 }
  }
});

$('.PopularProd-carousel, .RecomendedProd-carousel').owlCarousel({
  loop: false,
  margin: 20,
  nav: true,
  dots: false,
  responsive: {
    0: { items: 1 },
    600: { items: 2 },
    1000: { items: 3 },
    1200: { items: 4 }
  }
});

  // $('.PopularProd-carousel, .RecomendedProd-carousel, FeatureProd2-carousel').owlCarousel({
  //   loop:true, margin:20, nav:true, dots:false,
  //   responsive:{0:{items:1},600:{items:1},1000:{items:6}}
  // });

  //  $('.FreatureProd-carousel').owlCarousel({
  //   loop:true, margin:30, nav:true, dots:false,
  //   responsive:{0:{items:1},600:{items:3},1000:{items:6}}
  // });


 


  document.querySelector(".RecomendedProd-carousel").innerHTML += db.Logos.map(l =>
    `<img style="padding:60px;gap:30px;" src="${l.image}" alt="${l.name}">`).join('');
  $('.BrandProd-carousel').owlCarousel({ loop:true, margin:10, nav:true, dots:false, responsive:{0:{items:1},600:{items:4},1000:{items:6}} });
});