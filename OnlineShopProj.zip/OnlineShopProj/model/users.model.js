let users = [
    { 
        "id": 1, 
        "username": "john_doe", 
        "email": "john@example.com",
        "password": "password123", // In production, hash this!
        "cart": [],
        "favorites": []
    },
    { 
        "id": 2, 
        "username": "jane_smith", 
        "email": "jane@example.com",
        "password": "password123",
        "cart": [],
        "favorites": []
    },
    { 
        "id": 3, 
        "username": "michael_brown", 
        "email": "michael@example.com",
        "password": "password123",
        "cart": [],
        "favorites": []
    },
    { 
        "id": 4, 
        "username": "emily_clark", 
        "email": "emily@example.com",
        "password": "password123",
        "cart": [],
        "favorites": []
    },
    { 
        "id": 5, 
        "username": "david_jones", 
        "email": "david@example.com",
        "password": "password123",
        "cart": [],
        "favorites": []
    },
    { 
        "id": 6, 
        "username": "sophia_wilson", 
        "email": "sophia@example.com",
        "password": "password123",
        "cart": [],
        "favorites": []
    },
    { 
        "id": 7, 
        "username": "liam_miller", 
        "email": "liam@example.com",
        "password": "password123",
        "cart": [],
        "favorites": []
    },
    { 
        "id": 8, 
        "username": "olivia_davis", 
        "email": "olivia@example.com",
        "password": "password123",
        "cart": [],
        "favorites": []
    },
    { 
        "id": 9, 
        "username": "noah_moore", 
        "email": "noah@example.com",
        "password": "password123",
        "cart": [],
        "favorites": []
    },
    { 
        "id": 10, 
        "username": "isabella_taylor", 
        "email": "isabella@example.com",
        "password": "password123",
        "cart": [],
        "favorites": []
    }
];

module.exports = users;