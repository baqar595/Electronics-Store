let carts = [
  
  { userId: 1, items: [ { productId: 10, quantity: 2 } ] },
  { userId: 2, items: [] }
];

module.exports = carts;
